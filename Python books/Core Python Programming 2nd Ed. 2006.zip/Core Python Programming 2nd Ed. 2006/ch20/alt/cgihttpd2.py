#!/usr/bin/env python

from CGIHTTPServer import test;test()
